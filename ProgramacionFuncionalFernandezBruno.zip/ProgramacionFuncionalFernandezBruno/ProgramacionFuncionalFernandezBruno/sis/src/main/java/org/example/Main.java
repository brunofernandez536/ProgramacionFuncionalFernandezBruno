package org.example;
import java.util.*;
import java.util.stream.*;

public class Main {
    public static void main(String[] args) {
        // Lista de alumnos de ejemplo
        List<Alumno> alumnos = List.of(
                new Alumno("Raul", 8.5, "Lengua"),
                new Alumno("Seba", 6.0, "Historia"),
                new Alumno("Pepe", 9.0, "Matemática"),
                new Alumno("Martin", 7.5, "Literatura"),
                new Alumno("Pedro", 10.0, "Literatura"),
                new Alumno("Martín", 4.0, "Literatura"),
                new Alumno("Carla", 9.5, "Ciencias Sociales")
        );

        //Nombres de los alumnos aprobados (nota ≥ 7) en mayúsculas y ordenados
        List<String> aprobados = alumnos.stream()
                .filter(a -> a.getNota() >= 7)
                .map(a -> a.getNombre().toUpperCase())
                .sorted()
                .toList();

        System.out.println("Alumnos aprobados en mayúsculas y ordenados:");
        aprobados.forEach(System.out::println);

        //Calcular el promedio general de notas
        double promedioGeneral = alumnos.stream()
                .mapToDouble(Alumno::getNota)
                .average()
                .orElse(0.0);

        System.out.println("\nPromedio general de notas: " + promedioGeneral);

        //Agrupar alumnos por curso
        Map<String, List<Alumno>> alumnosPorCurso = alumnos.stream()
                .collect(Collectors.groupingBy(Alumno::getCurso));

        System.out.println("\nAlumnos agrupados por curso:");
        alumnosPorCurso.forEach((curso, lista) -> {
            System.out.println(curso + ": " + lista);
        });

        //Obtener los 3 mejores promedios
        List<Alumno> top3 = alumnos.stream()
                .sorted(Comparator.comparingDouble(Alumno::getNota).reversed())
                .limit(3)
                .toList();

        System.out.println("\nTop 3 mejores alumnos:");
        top3.forEach(System.out::println);

        // Lista de productos de ejemplo
        List<Producto> productos = List.of(
                new Producto("Silla", "Electrónica", 250.0, 5),
                new Producto("Mouse", "Electrónica", 80.0, 20),
                new Producto("Televisor", "Muebles", 120.0, 10),
                new Producto("Mesa", "Muebles", 300.0, 3),
                new Producto("Auriculares", "Ropa", 50.0, 15),
                new Producto("Pantalón", "Ropa", 110.0, 8),
                new Producto("Camiseta", "Electrónica", 150.0, 12)
        );

        //Productos con precio > 100 ordenados por precio descendente
        List<Producto> productosCaros = productos.stream()
                .filter(p -> p.getPrecio() > 100)
                .sorted(Comparator.comparingDouble(Producto::getPrecio).reversed())
                .toList();

        System.out.println("Productos con precio mayor a 100 (ordenados por precio descendente):");
        productosCaros.forEach(System.out::println);

        //Agrupar productos por categoría y calcular stock total por categoría
        Map<String, Integer> stockPorCategoria = productos.stream()
                .collect(Collectors.groupingBy(
                        Producto::getCategoria,
                        Collectors.summingInt(Producto::getStock)
                ));

        System.out.println("\nStock total por categoría:");
        stockPorCategoria.forEach((categoria, stockTotal) ->
                System.out.println(categoria + ": " + stockTotal + " unidades")
        );

        //Generar un String con nombre y precio separados por “;”
        String productosString = productos.stream()
                .map(p -> p.getNombre() + " - $" + p.getPrecio())
                .collect(Collectors.joining("; "));

        System.out.println("\nLista de productos (nombre y precio):");
        System.out.println(productosString);

        //Calcular precio promedio general
        double promedioGeneral1 = productos.stream()
                .mapToDouble(Producto::getPrecio)
                .average()
                .orElse(0.0);

        System.out.println("\nPrecio promedio general: $" + promedioGeneral1);

        //Calcular precio promedio por categoría
        Map<String, Double> promedioPorCategoria = productos.stream()
                .collect(Collectors.groupingBy(
                        Producto::getCategoria,
                        Collectors.averagingDouble(Producto::getPrecio)
                ));

        System.out.println("\nPrecio promedio por categoría:");
        promedioPorCategoria.forEach((categoria, promedio) ->
                System.out.println(categoria + ": $" + promedio)
        );

        // Lista de libros de ejemplo
        List<Libro> libros = List.of(
                new Libro("Cien años de soledad", "Gabriel García Márquez", 471, 2500.0),
                new Libro("El Principito", "Antoine de Saint-Exupéry", 120, 1500.0),
                new Libro("Don Quijote de la Mancha", "Miguel de Cervantes", 863, 3000.0),
                new Libro("Rayuela", "Julio Cortázar", 400, 2200.0),
                new Libro("Ficciones", "Jorge Luis Borges", 200, 1800.0),
                new Libro("El Aleph", "Jorge Luis Borges", 170, 1600.0),
                new Libro("Crónica de una muerte anunciada", "Gabriel García Márquez", 120, 1900.0)
        );

        //Listar títulos de libros con más de 300 páginas, ordenados alfabéticamente
        List<String> librosLargos = libros.stream()
                .filter(l -> l.getPaginas() > 300)
                .map(Libro::getTitulo)
                .sorted()
                .toList();

        System.out.println("Libros con más de 300 páginas (ordenados alfabéticamente):");
        librosLargos.forEach(System.out::println);

        //Calcular el promedio de páginas
        double promedioPaginas = libros.stream()
                .mapToInt(Libro::getPaginas)
                .average()
                .orElse(0.0);

        System.out.println("\nPromedio de páginas: " + promedioPaginas);

        //Agrupar libros por autor y contar cuántos libros tiene cada uno
        Map<String, Long> librosPorAutor = libros.stream()
                .collect(Collectors.groupingBy(
                        Libro::getAutor,
                        Collectors.counting()
                ));

        System.out.println("\nCantidad de libros por autor:");
        librosPorAutor.forEach((autor, cantidad) ->
                System.out.println(autor + ": " + cantidad + " libro(s)")
        );

        //Obtener el libro más caro
        libros.stream()
                .max(Comparator.comparingDouble(Libro::getPrecio))
                .ifPresent(libroMasCaro -> System.out.println("\nLibro más caro: " + libroMasCaro));


        //Lista de empleados de ejemplo
        List<Empleado> empleados = List.of(
                new Empleado("Juan", "Ventas", 2500.0, 28),
                new Empleado("Ana", "Marketing", 1800.0, 32),
                new Empleado("Pedro", "Ventas", 3000.0, 25),
                new Empleado("Lucía", "IT", 4000.0, 30),
                new Empleado("Sofía", "IT", 2100.0, 22),
                new Empleado("Martín", "RRHH", 1900.0, 35),
                new Empleado("Carla", "Marketing", 2200.0, 24)
        );

        //Empleados con salario > 2000, ordenados por salario descendente
        List<Empleado> empleadosBienPagos = empleados.stream()
                .filter(e -> e.getSalario() > 2000)
                .sorted(Comparator.comparingDouble(Empleado::getSalario).reversed())
                .toList();

        System.out.println("Empleados con salario mayor a 2000 (ordenados por salario descendente):");
        empleadosBienPagos.forEach(System.out::println);

        //Calcular salario promedio general
        double salarioPromedio = empleados.stream()
                .mapToDouble(Empleado::getSalario)
                .average()
                .orElse(0.0);

        System.out.println("\nSalario promedio general: $" + salarioPromedio);

        //Agrupar empleados por departamento y calcular suma de salarios
        Map<String, Double> sumaSalariosPorDepto = empleados.stream()
                .collect(Collectors.groupingBy(
                        Empleado::getDepartamento,
                        Collectors.summingDouble(Empleado::getSalario)
                ));

        System.out.println("\nSuma de salarios por departamento:");
        sumaSalariosPorDepto.forEach((depto, suma) ->
                System.out.println(depto + ": $" + suma)
        );

        //Nombres de los 2 empleados más jóvenes
        List<String> empleadosMasJovenes = empleados.stream()
                .sorted(Comparator.comparingInt(Empleado::getEdad))
                .limit(2)
                .map(Empleado::getNombre)
                .toList();

        System.out.println("\nLos 2 empleados más jóvenes:");
        empleadosMasJovenes.forEach(System.out::println);

    }

}
